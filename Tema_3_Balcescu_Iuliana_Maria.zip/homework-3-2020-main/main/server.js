const app = require('./app');

app.listen(8080, () => {
    console.log('Server started on port 8080...');
});